import mongoose, { Schema, Document, Model } from "mongoose";

export interface ICliente extends Document {
  nombre: string;
  correo: string;
  telefono: string;
  creadoEn: Date;
}

const ClienteSchema = new Schema<ICliente>({
  nombre: { type: String, required: false },
  correo: { type: String, required: true, unique: true },
  telefono: { type: String, required: true },
  creadoEn: { type: Date, default: Date.now },
});

// ✅ Evita registrar el modelo más de una vez
export const Cliente: Model<ICliente> =
  mongoose.models.Cliente || mongoose.model<ICliente>("Cliente", ClienteSchema);
