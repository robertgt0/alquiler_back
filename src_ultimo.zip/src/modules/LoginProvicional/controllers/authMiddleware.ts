// src/modules/LoginProvisional/controllers/authMiddleware.ts
import { Request, Response, NextFunction } from "express";
import { verifyToken } from "../utils/jwt";

export interface AuthenticatedRequest extends Request {
  clienteId?: string;
}

/**
 * Middleware que valida el token JWT y añade clienteId al request.
 */
export function authMiddleware(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) {
  const authHeader = req.headers.authorization;
  if (!authHeader)
    return res.status(401).json({ error: "No se proporcionó token" });

  const token = authHeader.split(" ")[1];
  try {
    const payload = verifyToken(token) as { clienteId: string };
    req.clienteId = payload.clienteId;
    next();
  } catch {
    return res.status(401).json({ error: "Token inválido o expirado" });
  }
}
