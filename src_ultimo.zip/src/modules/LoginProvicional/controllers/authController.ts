// src/modules/LoginProvisional/controllers/authController.ts
import { Request, Response } from "express";
import { generateToken } from "../utils/jwt";
import { Cliente } from "../models/Cliente"; // ✅ corregido import

/**
 * Controlador para registrar o iniciar sesión de un cliente.
 */
export async function registerOrLogin(req: Request, res: Response) {
  try {
    const { correo, telefono, nombre } = req.body;

    if (!correo || !telefono) {
      return res
        .status(400)
        .json({ error: "Correo y teléfono son requeridos" });
    }

    // Buscar si el usuario ya existe
    let cliente = await Cliente.findOne({ correo });

    // Si no existe, crearlo
    if (!cliente) {
      cliente = await Cliente.create({
        nombre: nombre || "Usuario",
        correo,
        telefono,
      });
    }

    // Generar token JWT con clienteId
    const token = generateToken({ clienteId: cliente._id });

    return res.json({
      token,
      clienteId: cliente._id,
      nombre: cliente.nombre,
      correo: cliente.correo,
      telefono: cliente.telefono,
    });
  } catch (error) {
    console.error("❌ Error en registerOrLogin:", error);
    return res.status(500).json({ error: "Error interno del servidor" });
  }
}
