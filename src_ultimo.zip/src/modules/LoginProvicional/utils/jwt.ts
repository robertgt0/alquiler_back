import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "dev_secret";

/**
 * Genera un token JWT con un payload.
 */
export function generateToken(payload: object): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "1d" });
}

/**
 * Verifica y decodifica un token JWT.
 */
export function verifyToken(token: string): any {
  return jwt.verify(token, JWT_SECRET);
}
