// src/modules/LoginProvisional/routes/cliente.routes.ts
import { Router, Request, Response } from "express";
import { Cliente } from "../models/Cliente"; // ✅ corregido import
import { generateToken } from "../utils/jwt";

const router = Router();

/**
 * POST /api/clientes/auth
 * Registra o inicia sesión de un cliente según su correo/teléfono
 */
router.post("/auth", async (req: Request, res: Response) => {
  try {
    const { correo, telefono, nombre } = req.body;

    if (!correo || !telefono) {
      return res.status(400).json({ error: "Correo y teléfono son requeridos" });
    }

    // Buscar si el cliente ya existe
    let cliente = await Cliente.findOne({ correo });

    // Si no existe, crearlo
    if (!cliente) {
      const nuevoCliente = new Cliente({ correo, telefono, nombre });
      cliente = await nuevoCliente.save();
    }

    // Generar token con el id del cliente
    const token = generateToken({ clienteId: cliente._id });

    return res.status(200).json({
      token,
      cliente: {
        id: cliente._id,
        correo: cliente.correo,
        telefono: cliente.telefono,
        nombre: cliente.nombre,
      },
    });
  } catch (error) {
    console.error("❌ Error en /clientes/auth:", error);
    return res.status(500).json({ error: "Error interno del servidor" });
  }
});

export default router;
